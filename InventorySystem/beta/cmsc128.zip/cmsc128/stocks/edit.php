<?php
	include('conn.php');
	$id=$_GET['id'];
	$query=mysqli_query($conn,"select * from `stocks_inventory` where stocks_id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title> Stocks Inventory </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<h2>Edit</h2>
	<form method="POST" action="update.php?id=<?php echo $id; ?>">

	<div class ="form-group" style="margin-left: 50px">
		<label> DTP (Transfer Papers): </label><input type="number" min="0" value="<?php echo $row['transfer_papers']; ?>" name="transfer_papers" class="col-form-label" style="width:200px; margin-left:5px"><br><br>
	</div>

	<div class ="form-group" style="margin-left: 50px">
		<label> Sublimation Papers: </label><input type="number" min="0" value="<?php echo $row['sublimation_papers']; ?>" name="sublimation_papers" class="col-form-label" style="width:200px; margin-left:18px"><br><br>
	</div>

	<div class ="form-group" style="margin-left: 50px">
		<label> Printed Outputs: </label><input type="number" min="0" value="<?php echo $row['printed_outputs']; ?>" name="printed_outputs" class="col-form-label" style="width:200px; margin-left:41px"><br><br>
	</div>

	<div class ="form-group" style="margin-left: 50px">
		<label> Shirts: </label><input type="number" min="0" value="<?php echo $row['shirts']; ?>" name="shirts" class="col-form-label" style="width:200px; margin-left:113px"><br><br>
    </div>

	<div class ="form-group" style="margin-left: 50px">
		<label> Logo Stickers: </label><input type="number" min="0" value="<?php echo $row['logo_stickers']; ?>" name="logo_stickers" class="col-form-label" style="width:200px; margin-left:57px"><br><br>
	</div>
	<button type="submit" name="add" class="btn btn-success" style="float: right; margin-right:1305px"> Update </button>
	<a href="index.php" button type="submit" name="add" class="btn btn-secondary" style="float: left; margin-left:50px">Back</a>


	</form>
</body>
</html>