<!DOCTYPE html>
<html>
<head>
<title>STOCKS INVENTORY</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
	<div>
		<table border="1">
		<div class="container mt-3">
		<table class="table table-hover">
			<thead>
				<th> DTP (Transfer Papers) </th>
				<th> Sublimation Papers </th>
				<th> Printed Outputs </th>
				<th> Shirts </th>
				<th> Logo Stickers </th>
			</thead>
			<tbody>
				<?php
					include('conn.php');
					$query=mysqli_query($conn,"select * from `stocks_inventory`");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
							<td><?php echo $row['transfer_papers']; ?></td>
							<td><?php echo $row['sublimation_papers']; ?></td>
							<td><?php echo $row['printed_outputs']; ?></td>
							<td><?php echo $row['shirts']; ?></td>
							<td><?php echo $row['logo_stickers']; ?></td>
							<td>
								<a href="edit.php?id=<?php echo $row['stocks_id']; ?>" button type="button" class="btn btn-outline-primary">Edit</a>
								<a href="delete.php?id=<?php echo $row['stocks_id']; ?>" button type="button" class="btn btn-outline-danger"> Delete </a>
							</td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
	</div>
	
	<br><br><br>
	
	<div class="text-center">
	<button type="button" class="btn btn-outline-success" data-bs-toggle="collapse" data-bs-target="#demo"> Add Stocks </button>
	</div>

	<div class="collapse" id="demo">
		<form method="POST" action="add.php" class="text-center">

		<div class ="form-group" style="margin-top: 50px; margin-left: 50px">
			<label> DTP (Transfer Papers): </label><input type="number" min="0" name="transfer_papers" placeholder="DTP (Transfer Papers)"class="col-form-label" style="width:200px; margin-left:5px" required><br><br>
		</div>
			
		<div class ="form-group" style="margin-left: 50px">	
			<label> Sublimation Papers: </label><input type="number" min="0" name="sublimation_papers" placeholder="Sublimation Papers" class="col-form-label" style="width:200px; margin-left:18px" required><br><br>
		</div>

		<div class ="form-group" style="margin-left: 50px">	
			<label> Printed Outputs: </label><input type="number" min="0" name="printed_outputs" placeholder="Printed Outputs" class="col-form-label" style="width:200px; margin-left:41px" required><br><br>
		</div>

		<div class ="form-group" style="margin-left: 50px">	
			<label> Shirts: </label><input type="number" name="shirts" min="0" placeholder="Shirts"class="col-form-label" style="width:200px; margin-left:113px" required><br><br>
		</div>

		<div class ="form-group" style="margin-left: 50px">			
		<label> Logo Stickers: </label><input type="number" min="0" name="logo_stickers" placeholder="Logo Stickers" class="col-form-label" style="width:200px; margin-left:57px" required>        
		</div>

		<br>
		<div class="tex-center">
			<button type="submit" name="add" class="btn btn-success"> Add</button>
		</div>
		</form>
	</div>
	<br>

</body>
</html>